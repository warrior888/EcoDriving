﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using dllExample.Castle.Raiden;

namespace DLLFlexibleExample
{
    class Program
    {
        static void Main(string[] args)
        {

            RaidenClass example = new RaidenClass();
            var x = example.cokolwiek();
            var dupa = 123;

        }
    }
}
