﻿
using dllExample.Ghosti.Thunder;
using dllExample.Ghosti.Thunder.Sito;

namespace dllExample.Castle.Raiden
{
    public class RaidenClass
    {

        public RaidenClass getRaiden()
        {
            SitoClass sito = new SitoClass();
            ThunderClass thunder = new ThunderClass();

            ThunderClass.protectedThunderClass  abc = new ThunderClass.protectedThunderClass();
            return null;
        }

        private RaidenClass privateRaiden()
        {

            return null;
        }


        public double cokolwiek()
        {

            return 9;
        }
    }
}
