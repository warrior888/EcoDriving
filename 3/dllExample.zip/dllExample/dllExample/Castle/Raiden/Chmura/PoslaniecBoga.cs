﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dllExample.Castle.Raiden.Chmura
{
    public class PoslaniecBoga
    {
        public void DoSomething()
        {
            
        }

        public PoslaniecBoga GetMe()
        {
            return null;
        }



        private int DoComputation()
        {
            return 8;
        }
    }
}
