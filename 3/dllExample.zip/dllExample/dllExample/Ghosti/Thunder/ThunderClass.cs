﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace dllExample.Ghosti.Thunder
{
class ThunderClass
    {

        void doNothing()
        {

        }

    public class protectedThunderClass
    {
        class Class1
        {

        }

    }

    
    




    }
}
