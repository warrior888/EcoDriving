﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dllExample.Ghosti.Thunder.Sito
{
    public class SitoClass
    {
        public int dajmiOsiem { get; set; }

        protected int zwroc2 ()
        {
            return 2;
        }

        private double prywatnedwaipol()
        {

            return 2.5;
        }


    }
}
