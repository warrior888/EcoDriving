﻿

namespace Graph
{
    public class Class1
    {
        
    }
}
