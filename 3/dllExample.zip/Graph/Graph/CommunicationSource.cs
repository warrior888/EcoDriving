﻿

namespace Graph
{
    public class CommunicationSource: CommunicationType
    {
        public string Line { get; set; }
    }
}
