﻿

namespace Graph
{
    public class CommunicationType
    {
        public string Type { get; set; }

    }
}
