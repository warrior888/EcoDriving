﻿
namespace Graph
{
    class Pig
    {
    }
}
