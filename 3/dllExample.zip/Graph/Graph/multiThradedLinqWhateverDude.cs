﻿

namespace Graph
{
    public class multiThradedLinqWhateverDude<T> : Tekken8ForAnAngelMortalCombat<T>
    {
    }
}
