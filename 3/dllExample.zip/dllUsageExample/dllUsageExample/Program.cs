﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dllUsageExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Kamehane kame1 = new Kamehane();
            var jazda = kame1.cokolwiek();
            var bleble = 3;
        }
    }
}
