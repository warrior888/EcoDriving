﻿

using dllExample.Castle.Raiden;

namespace dllUsageExample
{
   public class Kamehane
    {
        public double cokolwiek()
        {
            RaidenClass abc = new RaidenClass();
            var example =  abc.cokolwiek();
            return example;

        }

    }
  
}
